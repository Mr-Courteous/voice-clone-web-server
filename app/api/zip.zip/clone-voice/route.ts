// app/api/clone-voice/route.ts
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import fs from 'fs';
import path from 'path';

export async function POST(request: Request) {
  try {
    const formData = await request.formData();

    const file = (formData.get('file') || formData.get('audio') || formData.get('blob')) as File;
    const name = (formData.get('name') || formData.get('voiceName') || formData.get('voice_name')) as string;

    if (!file) return NextResponse.json({ error: 'Audio file missing.' }, { status: 400 });
    if (!name) return NextResponse.json({ error: 'Voice name missing.' }, { status: 400 });

    let user = await db.user.findFirst();
    if (!user) {
      user = await db.user.create({ data: { email: 'developer@example.com' } });
    }

    // Ensure the local storage directory exists
    const uploadDir = path.join(process.cwd(), 'public', 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }

    // Save the file on your local machine
    const filename = `${Date.now()}-${file.name || 'voice.webm'}`;
    const filePath = path.join(uploadDir, filename);
    const buffer = Buffer.from(await file.arrayBuffer());
    fs.writeFileSync(filePath, buffer);

    // Save the local relative path into your database
    const relativeUrl = `/uploads/${filename}`;

    const newVoice = await db.voice.create({
      data: {
        userId: user.id,
        name: name,
        sampleUrl: relativeUrl, // This points to your local file system now
        elevenVoiceId: `xtts_${Date.now()}`,
        status: 'ready',
      },
    });

    return NextResponse.json({ success: true, voice: newVoice });
  } catch (error: any) {
    console.error('Cloning error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}