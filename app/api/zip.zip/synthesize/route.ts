// app/api/synthesize/route.ts
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import fs from 'fs';
import path from 'path';

export async function POST(request: Request) {
    try {
        const { text, voiceId } = await request.json();

        // 1. Fetch voice metadata from your database
        let voice = await db.voice.findUnique({ where: { id: voiceId } });
        if (!voice) {
            voice = await db.voice.findFirst({ orderBy: { createdAt: 'desc' } });
        }

        if (!voice || !voice.sampleUrl) {
            return NextResponse.json({ error: 'Please record a voice sample first.' }, { status: 404 });
        }

        // 2. Resolve the local path of your recorded sample file
        const absoluteFilePath = path.join(process.cwd(), 'public', voice.sampleUrl);
        if (!fs.existsSync(absoluteFilePath)) {
            return NextResponse.json({ error: 'Recorded voice sample missing from server disk.' }, { status: 404 });
        }

        console.log(`[Testing Mode] Synthesizing text: "${text}" for voice: ${voice.name}`);

        // 3. Create a unique generated file copy to simulate real AI processing
        // This gives your frontend a distinct, new audio file URL every time you type text!
        const outputDir = path.join(process.cwd(), 'public', 'generated');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }

        const outputFilename = `cloned-output-${Date.now()}.webm`;
        const absoluteOutputPath = path.join(outputDir, outputFilename);

        // Duplicate the sample to create a unique test output track on disk
        fs.copyFileSync(absoluteFilePath, absoluteOutputPath);
        const generatedAudioUrl = `/generated/${outputFilename}`;

        console.log(`[Testing Mode] Success! Created new unique cloned output at: ${generatedAudioUrl}`);

        // 4. Save the new output file tracking details to your Prisma history database
        await db.generation.create({
            data: {
                voiceId: voice.id,
                text: text,
                audioUrl: generatedAudioUrl,
            }
        });

        return NextResponse.json({
            audioUrl: generatedAudioUrl,
            success: true
        });

    } catch (error: any) {
        console.error('Synthesis route testing error:', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}